package com.example.myapp_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyappSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyappSpringApplication.class, args);
	}

}
